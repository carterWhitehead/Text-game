import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Game state variables
        String currentRoom = "Entrance Hall";
        ArrayList<String> inventory = new ArrayList<>();

        int health = 100;
        boolean gameRunning = true;

        System.out.println("       tuff game room");
        System.out.println("sup fam, you're in a dark spooky room");
        System.out.println("find the key");
        System.out.println("open the door. ts is simple");
        System.out.println();

        // Main game loop
        while (gameRunning) {

            // Display current room
            describeRoom(currentRoom, inventory);

            // Check win/loss conditions
            if (currentRoom.equals("Exit Room") &&
                    inventory.contains("golden key")) {

                System.out.println("use the key fam, it's not that hard");
                System.out.println("to unlock a door");
                System.out.println();
                System.out.println("congwajewlayshuns, you got out");
                System.out.println("cool, you won");
                break;
            }

            if (health <= 0) {
                System.out.println("your fatahh died");
                System.out.println("womp womp, id try again ngl");
                break;
            }

            // Get player input
            System.out.print("\nWhat do you want to do? ");
            String command = scanner.nextLine().toLowerCase().trim();

            // Movement
            if (command.equals("north")) {

                if (currentRoom.equals("Entrance Hall")) {
                    currentRoom = "Library";
                } else if (currentRoom.equals("Library")) {
                    currentRoom = "Tower";
                } else if (currentRoom.equals("Dungeon")) {
                    currentRoom = "Entrance Hall";
                } else {
                    System.out.println("can't go that way fam");
                }

            } else if (command.equals("south")) {

                if (currentRoom.equals("Library")) {
                    currentRoom = "Entrance Hall";
                } else if (currentRoom.equals("Entrance Hall")) {
                    currentRoom = "Dungeon";
                } else if (currentRoom.equals("Tower")) {
                    currentRoom = "Library";
                } else {
                    System.out.println("can't go that way fam");
                }

            } else if (command.equals("east")) {

                if (currentRoom.equals("Entrance Hall")) {
                    currentRoom = "Exit Room";
                } else {
                    System.out.println("can't go that way fam");
                }

            } else if (command.equals("west")) {

                if (currentRoom.equals("Exit Room")) {
                    currentRoom = "Entrance Hall";
                } else {
                    System.out.println("can't go that way fam");
                }

            // Pick up golden key
            } else if (command.equals("take key") ||
                       command.equals("take golden key")) {

                if (currentRoom.equals("Tower")) {

                    if (!inventory.contains("golden key")) {
                        inventory.add("golden key");
                        System.out.println("got that key now, cool");
                    } else {
                        System.out.println("greedy ahh bozo");
                    }

                } else {
                    System.out.println("no key here fam");
                }

            // Search room
            } else if (command.equals("snoop")) {

                if (currentRoom.equals("Tower")) {
                    System.out.println("nosy ahh, you found the golden key tho");
                } else if (currentRoom.equals("Dungeon")) {
                    System.out.println("nosy ahh, nothing in here");
                } else {
                    System.out.println("nosy ahh, lol");
                }

            // Check inventory
            } else if (command.equals("inventory")) {

                if (inventory.isEmpty()) {
                    System.out.println("broke ahh");
                } else {
                    System.out.println("Inventory:");

                    for (String item : inventory) {
                        System.out.println("- " + item);
                    }
                }

            // Open exit
            } else if (command.equals("open door")) {

                if (currentRoom.equals("Exit Room")) {

                    if (inventory.contains("golden key")) {
                        System.out.println(
                            "ig the key be doin its job"
                        );
                        System.out.println("You escaped the castle");
                        System.out.println("nice, congwajewlayshuns");
                        gameRunning = false;
                    } else {
                        System.out.println("lol, bro don't got the key");
                    }

                } else {
                    System.out.println("lol, you ran into a wall.");
                }

            // Trap
            } else if (command.equals("enter dungeon")) {

                if (currentRoom.equals("Entrance Hall")) {
                    currentRoom = "Dungeon";
                    health -= 100;

                    System.out.println("ruh roh, that prolly hurt");
                    System.out.println("dead ahh, fr dead");
                } else {
                    System.out.println("get lost");
                }

            // Quit game
            } else if (command.equals("quit")) {

                System.out.println("Thanks for playing!");
                gameRunning = false;

            // Help
            } else if (command.equals("help")) {

                System.out.println("\nAvailable commands:");
                System.out.println("north");
                System.out.println("south");
                System.out.println("east");
                System.out.println("west");
                System.out.println("take key");
                System.out.println("search");
                System.out.println("inventory");
                System.out.println("open door");
                System.out.println("quit");

            // Invalid command
            } else {
                System.out.println("I don't understand that command.");
                System.out.println("Type 'help' to see available commands.");
            }
        }

        scanner.close();
    }

    // Method that describes each room
    public static void describeRoom(
            String room,
            ArrayList<String> inventory) {

        System.out.println("\n---------------------------------");
        System.out.println("Current Location: " + room);
        System.out.println("---------------------------------");

        if (room.equals("Entrance Hall")) {

            System.out.println("You are standing in the castle's entrance hall.");
            System.out.println("A hallway leads north to a library.");
            System.out.println("A dark passage leads south to the dungeon.");
            System.out.println("A door to the east leads to an exit room.");

        } else if (room.equals("Library")) {

            System.out.println("You are in a dusty library filled with ancient books.");
            System.out.println("The entrance hall is south.");
            System.out.println("A staircase leads north to a tall tower.");

        } else if (room.equals("Tower")) {

            System.out.println("You are standing at the top of a mysterious tower.");

            if (!inventory.contains("golden key")) {
                System.out.println("You notice something shiny on the floor.");
                System.out.println("It looks like a golden key.");
            } else {
                System.out.println("The tower is empty now.");
            }

            System.out.println("The library is south.");

        } else if (room.equals("Dungeon")) {

            System.out.println("You are in a dark and dangerous dungeon.");
            System.out.println("You hear strange noises around you.");
            System.out.println("The entrance hall is north.");

        } else if (room.equals("Exit Room")) {

            System.out.println("You are standing in front of a large locked door.");
            System.out.println("The entrance hall is west.");
            System.out.println("You need the golden key to escape.");
        }
    }
}